using System;
using System.Windows.Forms;
using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.View
{
    public partial class AdminLogIn : Form
    {
        public AdminLogIn() { InitializeComponent(); }

        private void button1_Click(object sender, EventArgs e)
        {
            string adminId = textBox1.Text.Trim();
            string password = textBox2.Text;

            if (string.IsNullOrWhiteSpace(adminId) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter Admin ID and Password.", "Admin Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Admin admin = new AdminController().SearchAdmin(adminId, password);
                if (admin == null)
                {
                    MessageBox.Show("Invalid Admin ID or Password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Hide();
                new AdminDashBoard(admin).Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database/Login error:\n" + ex.Message, "Admin Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            new LogInForm().Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
    }
}
