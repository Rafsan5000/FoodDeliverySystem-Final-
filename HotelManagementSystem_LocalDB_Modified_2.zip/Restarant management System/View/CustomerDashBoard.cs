﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;


namespace FoodDeliverySystem.View
{
    
    public partial class CustomerDashBoard : Form
    {
        Customer customer;

        public string selectedBookingId;

        public CustomerDashBoard(Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
        }
        private void LoadCustomerOrders()
        {
            OrderController oc = new OrderController();
            var bookings = new BookingController().GetCustomerBookings(customer.CustomerId);
            dataGridView1.DataSource = bookings;
        }
        public void LoadForm(Form Form)
        {
            panel2.Controls.Clear();
            Form.TopLevel = false;
            Form.Dock = DockStyle.Fill;
            panel2.Controls.Add(Form);
            Form.Show(); 
        }

        public void ShowCustomerInfo()
        {
            panel2.Controls.Clear();


            Label[] labels = { label2, label3, label4, label5, label8, label7, label9,label10 };

            foreach (var label in labels)
            {
                panel2.Controls.Add(label);
            }


            TextBox[] textBoxes = { textBox1, textBox2, textBox3,  textBox5, textBox6 };

            foreach (var textBox in textBoxes)
            {
                panel2.Controls.Add(textBox);
            }

            panel2.Controls.Add(comboBox1);
            panel2.Controls.Add(button5);
            panel2.Controls.Add(button4);

            panel2.Controls.Add(dataGridView1);

            label1.Text = "Your ID: " + customer.CustomerId;
            textBox1.Text = customer.Name;
            textBox2.Text = customer.Password;
            textBox3.Text = customer.Email;
            comboBox1.SelectedItem = customer.Gender;
            textBox5.Text = customer.Address;
            textBox6.Text = customer.Security;
            textBox7.Text = customer.Number;

            LoadCustomerOrders();



        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogInForm lg = new LogInForm();
            lg.Show();
        }

        private void CustomerDashBoard_Load(object sender, EventArgs e)
        {
            label1.Text = "Your ID: " + customer.CustomerId;
            textBox1.Text = customer.Name;
            textBox2.Text = customer.Password;
            textBox3.Text = customer.Email;
            comboBox1.SelectedItem= customer.Gender;
            textBox5.Text = customer.Address;
            textBox6.Text = customer.Security;
            textBox7.Text = customer.Number;
            ShowCustomerInfo();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ShowCustomerInfo();

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string status = "Active";
            string customerId= customer.CustomerId ;
            string name = textBox1.Text;
            string password = textBox2.Text;
            string email = textBox3.Text;
            string gender = comboBox1.SelectedItem.ToString(); 
            string address = textBox5.Text;
            string security = textBox6.Text;
            string number = textBox7.Text;

            Customer c = new Customer(customerId, name, password, email, gender, security, status, address, number);
            CustomerController cc = new CustomerController();
            cc.UpdateCustomer(c);

            LogIn l = new LogIn(customerId, password, security,"Customer");
            LogInController lg =new LogInController();
            lg.UpdateLogIn(l);

            customer = c;

            MessageBox.Show("Information Updated Succesfully");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadForm(new HotelBookingForm(customer));
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            //ShowCustomerInfo();
            //OrderController oc = new OrderController();
            //dataGridView1.DataSource = oc.GetCustomerOrder(customer.CustomerId);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                selectedBookingId = row.Cells["BookingId"].Value?.ToString();  
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedBookingId))
            {
                new BookingController().CancelBooking(selectedBookingId, customer.CustomerId);
                MessageBox.Show("Booking cancelled successfully.", "Information", MessageBoxButtons.OK);
                selectedBookingId = null;
                dataGridView1.DataSource = new BookingController().GetCustomerBookings(customer.CustomerId);
                dataGridView1.Refresh();
            }
            else MessageBox.Show("Please select a booking to cancel.");
        }

    }
}
