﻿using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodDeliverySystem.View
{
    public partial class EmployeeDashBoard : Form
    {
        Employee employee;

        public EmployeeDashBoard(Employee employee)
        {
            InitializeComponent();
            this.employee = employee;
           label4.Text="Id : "+ employee.EmployeeId;
        }


        public void LoadForm(Form Form)
        {
            panel2.Controls.Clear();
            Form.TopLevel = false;
            Form.Dock = DockStyle.Fill;
            panel2.Controls.Add(Form);
            Form.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogInForm lg = new LogInForm();
            lg.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadForm(new EmployeeBookingForm());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadForm(new EmployeeBookingForm());
        }

       

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            HotelController h = new HotelController();
            CustomerController c = new CustomerController();
            label2.Text = " Total Guest : " + c.ShowTotalCustomers();
            label3.Text=" Total Booking : "+h.ShowTotalBookings();
            label1.Text=" Available Rooms : " + h.ShowAvailableRooms();
        }

         public void ShowInfo()
        {
            HotelController h = new HotelController();
            CustomerController c = new CustomerController();
            panel2.Controls.Clear();
            label2.Text = " Total Guest : " + c.ShowTotalCustomers();
            label3.Text = " Total Booking : " + h.ShowTotalBookings();
            label1.Text = " Available Rooms : " + h.ShowAvailableRooms();

            

            panel2.Controls.Add(label1);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label3);
        }
        private void button4_Click(object sender, EventArgs e)
        {
            ShowInfo();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
