﻿using FoodDeliverySystem.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace FoodDeliverySystem.View
{
    public partial class ConfirmOrder : Form
    {
        public ConfirmOrder()
        {
            InitializeComponent();

            string orderId = textBox1.Text;
        }

        private void ConfirmOrder_Load(object sender, EventArgs e)
        {
            OrderController oc = new OrderController();
            dataGridView1.DataSource = oc.GetAllOrders();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow dvr = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = dvr.Cells[0].Value.ToString();
                string status = dvr.Cells[7].Value.ToString();

                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;

                if (status == "Panding")
                {
                    radioButton3.Checked = true;
                }
                else if (status == "Rejected")
                {
                    radioButton2.Checked = true;
                }
                else if (status == "Accepted")
                {
                    radioButton1.Checked = true;
                }

                textBox1.Enabled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string orderId = textBox1.Text;

            string status = "";

            if (radioButton1.Checked)
            {
                status = "Accepted";
            }
            else if (radioButton2.Checked)
            {
                status = "Rejected";
            }
            else if (radioButton3.Checked)
            {
                status = "Pending";
            }
            else
            {
                MessageBox.Show("Please select a status checkbox.", "Warning", MessageBoxButtons.OK);
                return;
            }

            OrderController oc = new OrderController();
            Order order = new Order();


            order.OrderId = orderId;
            order.PaymentStatus = status;
             

            oc.UpdateOrderStatus(order);
            MessageBox.Show("Order status updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            dataGridView1.DataSource = oc.GetAllOrders();
            dataGridView1.Refresh();

            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            textBox1.Text = null;
        }
    }
}
