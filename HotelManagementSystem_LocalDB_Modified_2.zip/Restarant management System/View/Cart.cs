﻿using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace FoodDeliverySystem.View
{
    public partial class Cart : Form
    {
        private string productList;
        private double grandTotal;
        private string customerId;
        Customer customer;
        Order order;
        public Cart(string productList, double grandTotal, Customer customer)
        {
            InitializeComponent();
            this.productList = productList;
            this.grandTotal = grandTotal;
            this.customer = customer;
        }

        private void Cart_Load(object sender, EventArgs e)
        {
            LoadProductItems();
            label4.Text = $"Total Price: {grandTotal:C2}";
            radioButton1.Checked = true;
            
        }

        private void LoadProductItems()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ProductItem");
            dt.Columns.Add("Price");

            var foodController = new FoodController();
            var allFoods = foodController.GetAllFood();

            if (!string.IsNullOrEmpty(productList))
            {
                string[] items = productList.Split(',');

                foreach (string item in items)
                {
                    var parts = item.Trim().Split('x');
                    if (parts.Length == 2 && int.TryParse(parts[1], out int quantity))
                    {
                        string foodName = parts[0].Trim();
                        var food = allFoods.Find(f => f.FoodName.Equals(foodName, StringComparison.OrdinalIgnoreCase));
                        if (food != null)
                        {
                            double totalPrice = food.Price * quantity;
                            dt.Rows.Add($"{foodName} x{quantity}", totalPrice.ToString("C2"));
                        }
                        else
                        {
                            dt.Rows.Add(item.Trim(), "N/A");
                        }
                    }
                    else
                    {
                        dt.Rows.Add(item.Trim(), "");
                    }
                }
            }

            dataGridViewCart.DataSource = dt;
            dataGridViewCart.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCart.ReadOnly = true;
            dataGridViewCart.AllowUserToAddRows = false;
            dataGridViewCart.RowHeadersVisible = false;
        }



        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                
 
                if (customer != null)
                {
                    textBox1.ReadOnly = true;
                    textBox1.Text = customer.Address;
                }

                comboBox1.Enabled = true;
            }

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                textBox1.ReadOnly = false;
                textBox1.Text = "";
            }
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }


        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
       
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string newAddress = textBox1.Text.Trim();
            string selectedPaymentMethod = comboBox1.SelectedItem.ToString();

            if (string.IsNullOrEmpty(newAddress))
            {
                MessageBox.Show("Please enter a valid address.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            OrderController orderController = new OrderController();
            string latestOrderId = orderController.GetLatestOrderId();


            if (!string.IsNullOrEmpty(latestOrderId))
            {
                Order updateOrder = new Order
                {
                    OrderId = latestOrderId,
                    Address = newAddress,
                    PaymentMethod = selectedPaymentMethod
                };

                orderController.orders.UpdateOrderAddress(updateOrder);
                MessageBox.Show("Payment confirmed", "Information", MessageBoxButtons.OK);
            }
        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerDashBoard cd = new CustomerDashBoard(customer);
            cd.Show();
        }
    }

}