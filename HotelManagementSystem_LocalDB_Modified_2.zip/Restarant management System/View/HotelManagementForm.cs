using System;
using System.Drawing;
using System.Windows.Forms;
using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.View
{
    public class HotelManagementForm : Form
    {
        private readonly Admin admin;
        private DataGridView hotelsGrid, roomsGrid;
        private TextBox hid, hn, hl, hc, hd, rid, rnum, rtype, rcap, rprice, rd;
        private ComboBox rhotel, rstatus;

        public HotelManagementForm(Admin admin)
        {
            this.admin = admin;
            Text = "Hotel & Room Management - " + (admin == null ? "Admin" : admin.Name);
            BackColor = Color.FromArgb(35, 35, 35);
            ForeColor = Color.White;
            DockPadding.All = 8;
            Build();
            LoadData();
        }

        private Button B(string text) => new Button
        {
            Text = text, AutoSize = true,
            BackColor = Color.FromArgb(230, 126, 34),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat
        };

        private TextBox T(int width = 120) => new TextBox
        {
            Width = width, BackColor = Color.FromArgb(55, 55, 55), ForeColor = Color.White
        };

        private void Build()
        {
            TabControl tabs = new TabControl { Dock = DockStyle.Fill };
            TabPage hotels = new TabPage("Hotels") { BackColor = Color.FromArgb(35, 35, 35) };
            TabPage rooms = new TabPage("Rooms") { BackColor = Color.FromArgb(35, 35, 35) };
            tabs.TabPages.Add(hotels); tabs.TabPages.Add(rooms); Controls.Add(tabs);

            hotelsGrid = new DataGridView
            {
                Dock = DockStyle.Bottom, Height = 260, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false, AllowUserToAddRows = false
            };
            hotelsGrid.SelectionChanged += (s, e) => HotelSelect();
            hotels.Controls.Add(hotelsGrid);

            FlowLayoutPanel hp = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(10), AutoScroll = true };
            hotels.Controls.Add(hp);
            hid = T(); hn = T(180); hl = T(220); hc = T(); hd = T(300);
            Button addHotel = B("Add Hotel"), updateHotel = B("Update"), deactivateHotel = B("Deactivate"), clearHotel = B("Clear");
            addHotel.Click += (s, e) => SaveHotel(false); updateHotel.Click += (s, e) => SaveHotel(true);
            deactivateHotel.Click += (s, e) => DeactivateHotel(); clearHotel.Click += (s, e) => ClearHotel();
            Add(hp, "Hotel ID", hid); Add(hp, "Hotel Name", hn); Add(hp, "Location", hl); Add(hp, "Contact", hc); Add(hp, "Description", hd);
            hp.Controls.Add(addHotel); hp.Controls.Add(updateHotel); hp.Controls.Add(deactivateHotel); hp.Controls.Add(clearHotel);

            roomsGrid = new DataGridView
            {
                Dock = DockStyle.Bottom, Height = 260, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false, AllowUserToAddRows = false
            };
            roomsGrid.SelectionChanged += (s, e) => RoomSelect(); rooms.Controls.Add(roomsGrid);
            FlowLayoutPanel rp = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(10), AutoScroll = true };
            rooms.Controls.Add(rp);
            rhotel = new ComboBox { Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
            rstatus = new ComboBox { Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
            rstatus.Items.AddRange(new object[] { "Available", "Booked", "Maintenance" }); rstatus.SelectedIndex = 0;
            rid = T(); rnum = T(); rtype = T(); rcap = T(); rprice = T(); rd = T(260);
            Button addRoom = B("Add Room"), updateRoom = B("Update"), deleteRoom = B("Delete");
            addRoom.Click += (s, e) => SaveRoom(false); updateRoom.Click += (s, e) => SaveRoom(true); deleteRoom.Click += (s, e) => DeleteRoom();
            Add(rp, "Room ID", rid); Add(rp, "Hotel", rhotel); Add(rp, "Room Number", rnum); Add(rp, "Room Type", rtype);
            Add(rp, "Capacity", rcap); Add(rp, "Price/Night", rprice); Add(rp, "Description", rd); Add(rp, "Status", rstatus);
            rp.Controls.Add(addRoom); rp.Controls.Add(updateRoom); rp.Controls.Add(deleteRoom);
        }

        private static void Add(FlowLayoutPanel p, string name, Control control)
        {
            p.Controls.Add(new Label { Text = name + ":", AutoSize = true, Margin = new Padding(8, 8, 2, 8) });
            p.Controls.Add(control);
        }

        private void LoadData()
        {
            try
            {
                HotelController hc = new HotelController();
                hotelsGrid.DataSource = hc.GetAllHotels();
                rhotel.DataSource = hc.GetAllHotels(true);
                rhotel.DisplayMember = "HotelName";
                rhotel.ValueMember = "HotelId";
                roomsGrid.DataSource = new RoomController().GetAllRooms();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Database Error"); }
        }

        private void HotelSelect()
        {
            Hotel h = hotelsGrid.CurrentRow == null ? null : hotelsGrid.CurrentRow.DataBoundItem as Hotel;
            if (h == null) return;
            hid.Text = h.HotelId; hn.Text = h.HotelName; hl.Text = h.Location; hc.Text = h.ContactNumber; hd.Text = h.Description;
        }

        private void RoomSelect()
        {
            Room r = roomsGrid.CurrentRow == null ? null : roomsGrid.CurrentRow.DataBoundItem as Room;
            if (r == null) return;
            rid.Text = r.RoomId; rnum.Text = r.RoomNumber; rtype.Text = r.RoomType; rcap.Text = r.Capacity.ToString();
            rprice.Text = r.PricePerNight.ToString("0.00"); rd.Text = r.Description; rstatus.SelectedItem = r.Status; rhotel.SelectedValue = r.HotelId;
        }

        private void SaveHotel(bool edit)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(hid.Text) || string.IsNullOrWhiteSpace(hn.Text) ||
                    string.IsNullOrWhiteSpace(hl.Text) || string.IsNullOrWhiteSpace(hc.Text))
                { MessageBox.Show("Hotel ID, name, location and contact are required."); return; }

                Hotel h = new Hotel
                {
                    HotelId = hid.Text.Trim(), HotelName = hn.Text.Trim(), Location = hl.Text.Trim(),
                    ContactNumber = hc.Text.Trim(), Description = hd.Text.Trim(), IsActive = true
                };
                HotelController controller = new HotelController();
                if (edit) controller.UpdateHotel(h); else controller.AddHotel(h);
                LoadData(); ClearHotel();
                MessageBox.Show(edit ? "Hotel updated." : "Hotel added.");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Hotel Error"); }
        }

        private void DeactivateHotel()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(hid.Text)) { MessageBox.Show("Select a hotel first."); return; }
                new HotelController().DeleteHotel(hid.Text.Trim()); LoadData(); ClearHotel(); MessageBox.Show("Hotel deactivated.");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Hotel Error"); }
        }

        private void ClearHotel() { hid.Clear(); hn.Clear(); hl.Clear(); hc.Clear(); hd.Clear(); }

        private void SaveRoom(bool edit)
        {
            try
            {
                int capacity; decimal price;
                if (rhotel.SelectedValue == null || string.IsNullOrWhiteSpace(rid.Text) || string.IsNullOrWhiteSpace(rnum.Text) ||
                    string.IsNullOrWhiteSpace(rtype.Text)) { MessageBox.Show("Room ID, hotel, room number and room type are required."); return; }
                if (!int.TryParse(rcap.Text, out capacity) || capacity <= 0) { MessageBox.Show("Capacity must be a positive number."); return; }
                if (!decimal.TryParse(rprice.Text, out price) || price < 0) { MessageBox.Show("Price must be a valid non-negative number."); return; }

                Room r = new Room
                {
                    RoomId = rid.Text.Trim(), HotelId = rhotel.SelectedValue.ToString(), RoomNumber = rnum.Text.Trim(),
                    RoomType = rtype.Text.Trim(), Capacity = capacity, PricePerNight = price,
                    Description = rd.Text.Trim(), Status = string.IsNullOrWhiteSpace(rstatus.Text) ? "Available" : rstatus.Text
                };
                RoomController controller = new RoomController(); if (edit) controller.UpdateRoom(r); else controller.AddRoom(r);
                LoadData(); MessageBox.Show(edit ? "Room updated." : "Room added.");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Room Error"); }
        }

        private void DeleteRoom()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(rid.Text)) { MessageBox.Show("Select a room first."); return; }
                new RoomController().DeleteRoom(rid.Text.Trim()); LoadData(); MessageBox.Show("Room deleted.");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Room Error"); }
        }
    }
}
