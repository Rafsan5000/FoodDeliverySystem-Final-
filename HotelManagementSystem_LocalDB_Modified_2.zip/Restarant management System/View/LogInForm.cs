using System;
using System.Windows.Forms;
using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.View
{
    public partial class LogInForm : Form
    {
        public LogInForm() { InitializeComponent(); }

        private void button5_Click(object sender, EventArgs e)
        {
            Hide();
            new ForgetPassword().Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            new RegisterForm().Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            new AdminLogIn().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string logId = textBox1.Text.Trim();
            string password = textBox2.Text;

            if (string.IsNullOrWhiteSpace(logId) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter User ID and Password.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                LogIn login = new LogInController().SearchLogIn(logId, password);

                if (login == null)
                {
                    MessageBox.Show("Invalid User ID or Password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.Equals(login.Role, "Customer", StringComparison.OrdinalIgnoreCase))
                {
                    Customer customer = new CustomerController().SearchCustomer(logId);
                    if (customer == null)
                    {
                        MessageBox.Show("Customer account was not found.");
                        return;
                    }
                    if (!string.Equals(customer.Status, "Active", StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Your account has been deactivated by the manager.");
                        return;
                    }
                    Hide();
                    new CustomerDashBoard(customer).Show();
                    return;
                }

                if (string.Equals(login.Role, "Employee", StringComparison.OrdinalIgnoreCase))
                {
                    Employee employee = new EmployeeController().SearchEmployee(logId);
                    if (employee == null)
                    {
                        MessageBox.Show("Employee account was not found.");
                        return;
                    }
                    Hide();
                    new EmployeeDashBoard(employee).Show();
                    return;
                }

                MessageBox.Show("Unsupported account role: " + login.Role);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database/Login error:\n" + ex.Message, "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (textBox2.PasswordChar == '\0')
            {
                textBox2.PasswordChar = '*';
                button6.BringToFront();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox2.PasswordChar == '*')
            {
                textBox2.PasswordChar = '\0';
                button5.BringToFront();
            }
        }

        private void label2_Click(object sender, EventArgs e) { }
        private void radioButton1_CheckedChanged(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
    }
}
