using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.Controller
{
    public class HotelController
    {
        public List<Hotel> GetAllHotels(bool activeOnly = false)
        {
            string sql = @"SELECT HotelId,HotelName,Location,ContactNumber,Description,ImagePath,IsActive
                           FROM dbo.Hotels" +
                         (activeOnly ? " WHERE IsActive=1" : "") +
                         " ORDER BY HotelName;";

            List<Hotel> list = new List<Hotel>();
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cn.Open();
                using (SqlDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Hotel
                        {
                            HotelId = r.GetString(0),
                            HotelName = r.GetString(1),
                            Location = r.GetString(2),
                            ContactNumber = r.GetString(3),
                            Description = r.IsDBNull(4) ? "" : r.GetString(4),
                            ImagePath = r.IsDBNull(5) ? "" : r.GetString(5),
                            IsActive = r.GetBoolean(6)
                        });
                    }
                }
            }
            return list;
        }

        public void AddHotel(Hotel hotel)
        {
            const string sql = @"INSERT INTO dbo.Hotels
                (HotelId,HotelName,Location,ContactNumber,Description,ImagePath)
                VALUES(@Id,@Name,@Location,@Contact,@Description,@ImagePath);";
            ExecuteHotel(sql, hotel, false);
        }

        public void UpdateHotel(Hotel hotel)
        {
            const string sql = @"UPDATE dbo.Hotels SET
                HotelName=@Name, Location=@Location, ContactNumber=@Contact,
                Description=@Description, ImagePath=@ImagePath, IsActive=@Active
                WHERE HotelId=@Id;";
            ExecuteHotel(sql, hotel, true);
        }

        public void DeleteHotel(string hotelId)
        {
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(
                "UPDATE dbo.Hotels SET IsActive=0 WHERE HotelId=@Id;", cn))
            {
                cmd.Parameters.Add("@Id", SqlDbType.VarChar, 50).Value = hotelId;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public int ShowTotalHotels() { return Scalar("SELECT COUNT(*) FROM dbo.Hotels WHERE IsActive=1;"); }
        public int ShowTotalRooms() { return Scalar("SELECT COUNT(*) FROM dbo.Rooms;"); }
        public int ShowAvailableRooms() { return Scalar("SELECT COUNT(*) FROM dbo.Rooms WHERE Status='Available';"); }
        public int ShowTotalBookings() { return Scalar("SELECT COUNT(*) FROM dbo.Bookings;"); }

        public decimal ShowRevenue()
        {
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(
                "SELECT ISNULL(SUM(TotalAmount),0) FROM dbo.Bookings WHERE BookingStatus<>'Cancelled';", cn))
            {
                cn.Open();
                return Convert.ToDecimal(cmd.ExecuteScalar());
            }
        }

        private static int Scalar(string sql)
        {
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        private static void ExecuteHotel(string sql, Hotel h, bool includeActive)
        {
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.Add("@Id", SqlDbType.VarChar, 50).Value = h.HotelId;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar, 120).Value = h.HotelName;
                cmd.Parameters.Add("@Location", SqlDbType.VarChar, 255).Value = h.Location;
                cmd.Parameters.Add("@Contact", SqlDbType.VarChar, 30).Value = h.ContactNumber;
                cmd.Parameters.Add("@Description", SqlDbType.VarChar, 500).Value =
                    (object)h.Description ?? DBNull.Value;
                cmd.Parameters.Add("@ImagePath", SqlDbType.VarChar, 255).Value =
                    (object)h.ImagePath ?? DBNull.Value;
                if (includeActive)
                    cmd.Parameters.Add("@Active", SqlDbType.Bit).Value = h.IsActive;

                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
