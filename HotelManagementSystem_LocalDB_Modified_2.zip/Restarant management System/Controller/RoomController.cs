using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.Controller
{
    public class RoomController
    {
        private const string SelectSql = @"
            SELECT r.RoomId,r.HotelId,h.HotelName,r.RoomNumber,r.RoomType,
                   r.Capacity,r.PricePerNight,r.Description,r.ImagePath,r.Status
            FROM dbo.Rooms r
            INNER JOIN dbo.Hotels h ON h.HotelId=r.HotelId";

        public List<Room> GetAllRooms()
        {
            return Query(SelectSql + " ORDER BY h.HotelName,r.RoomNumber;");
        }

        public List<Room> GetAvailableRooms()
        {
            return Query(SelectSql + @" WHERE r.Status='Available' AND h.IsActive=1
                                      ORDER BY h.HotelName,r.RoomNumber;");
        }

        public void AddRoom(Room room)
        {
            const string sql = @"INSERT INTO dbo.Rooms
                (RoomId,HotelId,RoomNumber,RoomType,Capacity,PricePerNight,Description,ImagePath,Status)
                VALUES(@Id,@HotelId,@Number,@Type,@Capacity,@Price,@Description,@ImagePath,@Status);";
            Execute(sql, room);
        }

        public void UpdateRoom(Room room)
        {
            const string sql = @"UPDATE dbo.Rooms SET
                HotelId=@HotelId, RoomNumber=@Number, RoomType=@Type,
                Capacity=@Capacity, PricePerNight=@Price, Description=@Description,
                ImagePath=@ImagePath, Status=@Status
                WHERE RoomId=@Id;";
            Execute(sql, room);
        }

        public void DeleteRoom(string roomId)
        {
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand("DELETE FROM dbo.Rooms WHERE RoomId=@Id;", cn))
            {
                cmd.Parameters.Add("@Id", SqlDbType.VarChar, 50).Value = roomId;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void SetStatus(string roomId, string status)
        {
            if (status != "Available" && status != "Booked" && status != "Maintenance")
                throw new ArgumentException("Invalid room status.");

            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(
                "UPDATE dbo.Rooms SET Status=@Status WHERE RoomId=@Id;", cn))
            {
                cmd.Parameters.Add("@Status", SqlDbType.VarChar, 30).Value = status;
                cmd.Parameters.Add("@Id", SqlDbType.VarChar, 50).Value = roomId;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        private static List<Room> Query(string sql)
        {
            List<Room> list = new List<Room>();
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cn.Open();
                using (SqlDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Room
                        {
                            RoomId = r.GetString(0),
                            HotelId = r.GetString(1),
                            HotelName = r.GetString(2),
                            RoomNumber = r.GetString(3),
                            RoomType = r.GetString(4),
                            Capacity = r.GetInt32(5),
                            PricePerNight = r.GetDecimal(6),
                            Description = r.IsDBNull(7) ? "" : r.GetString(7),
                            ImagePath = r.IsDBNull(8) ? "" : r.GetString(8),
                            Status = r.GetString(9)
                        });
                    }
                }
            }
            return list;
        }

        private static void Execute(string sql, Room r)
        {
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.Add("@Id", SqlDbType.VarChar, 50).Value = r.RoomId;
                cmd.Parameters.Add("@HotelId", SqlDbType.VarChar, 50).Value = r.HotelId;
                cmd.Parameters.Add("@Number", SqlDbType.VarChar, 30).Value = r.RoomNumber;
                cmd.Parameters.Add("@Type", SqlDbType.VarChar, 50).Value = r.RoomType;
                cmd.Parameters.Add("@Capacity", SqlDbType.Int).Value = r.Capacity;
                cmd.Parameters.Add("@Price", SqlDbType.Decimal).Value = r.PricePerNight;
                cmd.Parameters["@Price"].Precision = 12;
                cmd.Parameters["@Price"].Scale = 2;
                cmd.Parameters.Add("@Description", SqlDbType.VarChar, 500).Value =
                    (object)r.Description ?? DBNull.Value;
                cmd.Parameters.Add("@ImagePath", SqlDbType.VarChar, 255).Value =
                    (object)r.ImagePath ?? DBNull.Value;
                cmd.Parameters.Add("@Status", SqlDbType.VarChar, 30).Value =
                    string.IsNullOrWhiteSpace(r.Status) ? "Available" : r.Status;

                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
