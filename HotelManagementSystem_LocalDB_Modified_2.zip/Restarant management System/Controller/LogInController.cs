using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.Controller
{
    public class LogInController
    {
        private readonly LogIns service = new LogIns();

        public void AddLogIn(LogIn login)
        {
            service.AddLogIn(login);
        }

        public LogIn SearchLogIn(string logId)
        {
            return service.SearchLogIn(logId);
        }

        public LogIn SearchLogIn(string logId, string password)
        {
            return service.SearchLogIn(logId, password);
        }

        public void UpdateLogIn(LogIn login)
        {
            service.UpdateLogIn(login);
        }

        public void DeleteLogIn(string logId)
        {
            service.DeleteLogIn(logId);
        }
    }
}
