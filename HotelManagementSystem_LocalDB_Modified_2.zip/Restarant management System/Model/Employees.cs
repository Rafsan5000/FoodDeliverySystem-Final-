using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace FoodDeliverySystem.Model
{
    public class Employees
    {
        private readonly SqlDbDataAccess sda = new SqlDbDataAccess();

        public void AddEmployee(Employee employee)
        {
            const string sql = @"INSERT INTO dbo.Employee
                (EmployeeId,Password,Name,Address,Number,Salary,Security)
                VALUES(@EmployeeId,@Password,@Name,@Address,@Number,@Salary,@Security);";

            using (SqlCommand cmd = sda.GetQuery(sql))
            {
                AddParameters(cmd, employee);
                cmd.Connection.Open();
                try { cmd.ExecuteNonQuery(); }
                finally { cmd.Connection.Close(); }
            }
        }

        public void UpdateByAdmin(Employee employee)
        {
            const string sql = @"UPDATE dbo.Employee
                SET Password=@Password, Name=@Name, Address=@Address,
                    Number=@Number, Salary=@Salary, Security=@Security
                WHERE EmployeeId=@EmployeeId;";

            using (SqlCommand cmd = sda.GetQuery(sql))
            {
                AddParameters(cmd, employee);
                cmd.Connection.Open();
                try { cmd.ExecuteNonQuery(); }
                finally { cmd.Connection.Close(); }
            }
        }

        public void DeleteEmployee(string employeeId)
        {
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(
                "DELETE FROM dbo.Employee WHERE EmployeeId=@EmployeeId; DELETE FROM dbo.LogIn WHERE LogId=@EmployeeId;", cn))
            {
                cmd.Parameters.Add("@EmployeeId", SqlDbType.VarChar, 50).Value = employeeId;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public Employee SearchEmployee(string employeeId)
        {
            using (SqlCommand cmd = sda.GetQuery(
                "SELECT EmployeeId,Password,Name,Address,Number,Salary,Security FROM dbo.Employee WHERE EmployeeId=@EmployeeId;"))
            {
                cmd.Parameters.Add("@EmployeeId", SqlDbType.VarChar, 50).Value = employeeId;
                List<Employee> list = GetData(cmd);
                return list.Count > 0 ? list[0] : null;
            }
        }

        public List<Employee> GetAllEmployee()
        {
            using (SqlCommand cmd = sda.GetQuery(
                "SELECT EmployeeId,Password,Name,Address,Number,Salary,Security FROM dbo.Employee ORDER BY EmployeeId;"))
            {
                return GetData(cmd);
            }
        }

        public int GetEmployeeCount()
        {
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM dbo.Employee;", cn))
            {
                cn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public string GenerateNewEmployeeId()
        {
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(@"
                SELECT ISNULL(MAX(TRY_CONVERT(INT, SUBSTRING(EmployeeId, 3, 20))), 0) + 1
                FROM dbo.Employee
                WHERE EmployeeId LIKE 'E-[0-9]%';", cn))
            {
                cn.Open();
                int next = Convert.ToInt32(cmd.ExecuteScalar());
                return "E-" + next.ToString("D4");
            }
        }

        private List<Employee> GetData(SqlCommand cmd)
        {
            List<Employee> list = new List<Employee>();
            cmd.Connection.Open();
            try
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Employee
                        {
                            EmployeeId = reader.GetString(0),
                            Password = reader.GetString(1),
                            Name = reader.GetString(2),
                            Address = reader.GetString(3),
                            Number = reader.GetString(4),
                            Salary = reader.IsDBNull(5) ? 0 : reader.GetInt32(5),
                            Security = reader.GetString(6)
                        });
                    }
                }
            }
            finally { cmd.Connection.Close(); }
            return list;
        }

        private static void AddParameters(SqlCommand cmd, Employee employee)
        {
            cmd.Parameters.Add("@EmployeeId", SqlDbType.VarChar, 50).Value = employee.EmployeeId;
            cmd.Parameters.Add("@Password", SqlDbType.VarChar, 100).Value = employee.Password;
            cmd.Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = employee.Name;
            cmd.Parameters.Add("@Address", SqlDbType.VarChar, 255).Value = employee.Address;
            cmd.Parameters.Add("@Number", SqlDbType.VarChar, 20).Value = employee.Number;
            cmd.Parameters.Add("@Salary", SqlDbType.Int).Value = employee.Salary;
            cmd.Parameters.Add("@Security", SqlDbType.VarChar, 100).Value = employee.Security;
        }
    }
}
