using System;
using System.Configuration;
using System.Data.SqlClient;

namespace FoodDeliverySystem.Model
{
    /// <summary>
    /// Central SQL Server connection factory.
    /// The connection string is kept in App.config so every controller/model
    /// uses the same HotelManagementDB LocalDB connection.
    /// </summary>
    public class SqlDbDataAccess
    {
        private const string ConnectionName = "RestaurantDb";

        private static string ConnectionString
        {
            get
            {
                ConnectionStringSettings settings =
                    ConfigurationManager.ConnectionStrings[ConnectionName];

                if (settings == null || string.IsNullOrWhiteSpace(settings.ConnectionString))
                {
                    throw new ConfigurationErrorsException(
                        "Connection string 'RestaurantDb' was not found in App.config.");
                }

                return settings.ConnectionString;
            }
        }

        public SqlCommand GetQuery(string query)
        {
            return new SqlCommand(query, GetConnection());
        }

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }

        public static bool TestConnection(out string message)
        {
            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    message = "Connected to HotelManagementDB successfully.";
                    return true;
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return false;
            }
        }
    }
}
