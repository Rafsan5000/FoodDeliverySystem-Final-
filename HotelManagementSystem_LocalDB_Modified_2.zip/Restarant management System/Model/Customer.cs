﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDeliverySystem.Model
{
    public class Customer
    {
        private string customerId;
        private string name;
        private string email;
        private string password;
        private string gender;
        private string security;
        private string status;
        private string address;
        private string number;

        public Customer()
        {

        }

        public Customer( string customerId, string status)
        {
            this.CustomerId=customerId;
            this.Status = status;
        }
        

        public Customer(string customerId, string name,  string password, string email, string gender, string security, string status,string address,string number)
        {
            this.CustomerId = customerId;
            this.Name = name;
            this.Email = email;
            this.Password = password;
            this.Gender = gender;
            this.Security = security;
            this.Status = status;
            this.Address = address;
            this.Number = number;
        }

        public string CustomerId { get => customerId; set => customerId = value; }
        public string Name { get => name; set => name = value; }
        public string Email { get => email; set => email = value; }
        public string Password { get => password; set => password = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Security { get => security; set => security = value; }
        public string Status { get => status; set => status = value; }
        public string Address { get => address; set => address = value; }
        public string Number { get => number; set => number = value; }

    }
}
