namespace FoodDeliverySystem.Model
{
    public class Hotel
    {
        public string HotelId { get; set; }
        public string HotelName { get; set; }
        public string Location { get; set; }
        public string ContactNumber { get; set; }
        public string Description { get; set; }
        public string ImagePath { get; set; }
        public bool IsActive { get; set; }
    }
}
