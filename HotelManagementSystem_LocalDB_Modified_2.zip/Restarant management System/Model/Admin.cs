using System;
namespace FoodDeliverySystem.Model
{
    public class Admin
    {
        public Admin() { IsActive = true; }
        public Admin(string adminId,string password,string name,string number)
        { AdminId=adminId; Password=password; Name=name; Number=number; Role="Manager"; IsActive=true; }
        public string AdminId { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Number { get; set; }
        public string Role { get; set; }
        public bool IsActive { get; set; }
        public bool IsSuperAdmin { get { return string.Equals(Role,"SuperAdmin",StringComparison.OrdinalIgnoreCase); } }
    }
}
