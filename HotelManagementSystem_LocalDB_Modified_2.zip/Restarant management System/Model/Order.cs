﻿using System;

public class Order
{
    private string orderId;
    private string customerId;
    private double totalPrice;
    private DateTime date;
    private string productsName;
    private string address;
    private string paymentMethod;
    private string paymentStatus;
    public Order() { }

    public Order(string orderId, string customerId, double totalPrice, DateTime date, string productsName,string address, string paymentMethod, string paymentStatus)
    {
        this.orderId = orderId;
        this.customerId = customerId;
        this.totalPrice = totalPrice;
        this.date = date;
        this.productsName = productsName;
        this.address = address;
        this.PaymentMethod = paymentMethod;
        this.PaymentStatus = paymentStatus;
    }

    public string OrderId { get => orderId; set => orderId = value; }
    public string CustomerId { get => customerId; set => customerId = value; }
    public double TotalPrice { get => totalPrice; set => totalPrice = value; }
    public DateTime Date { get => date; set => date = value; }
    public string ProductsName { get => productsName; set => productsName = value; }
    public string Address { get=>address; set => address = value; }
    public string PaymentMethod { get => paymentMethod; set => paymentMethod = value; }
    public string PaymentStatus { get => paymentStatus; set => paymentStatus = value; }
}
