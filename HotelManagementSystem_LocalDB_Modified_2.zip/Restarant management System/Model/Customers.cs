﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace FoodDeliverySystem.Model
{
    public class Customers
    {
        SqlDbDataAccess sda = new SqlDbDataAccess();

        public void AddCustomer(Customer customer)
        {
            SqlCommand cmd = sda.GetQuery("INSERT INTO Customer VALUES(@CustomerId,@Name,@Password,@Email,@Gender,@Security,@Status,@Address,@Number);");
            cmd.Parameters.AddWithValue("@CustomerId", customer.CustomerId);
            cmd.Parameters.AddWithValue("@Name", customer.Name);
            cmd.Parameters.AddWithValue("@Password", customer.Password);
            cmd.Parameters.AddWithValue("@Email", customer.Email);
            cmd.Parameters.AddWithValue("@Gender", customer.Gender);
            cmd.Parameters.AddWithValue("@Security", customer.Security);
            cmd.Parameters.AddWithValue("@Status", "Active");
            cmd.Parameters.AddWithValue("@Address", customer.Address);
            cmd.Parameters.AddWithValue("@Number",customer.Number);
            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
        }


        public void DeleteCustomer(string customerId)
        {
            SqlCommand cmd = sda.GetQuery("DELETE From Customer WHERE customerId=@CustomerId;");
            cmd.Parameters.AddWithValue("@CustomerId", customerId);

            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();

        }

        public List<Customer> GetData(SqlCommand cmd)
        {
            if (cmd.Connection.State != ConnectionState.Open)
            {
                cmd.Connection.Open();
            }

            List<Customer> customerList = new List<Customer>();

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Customer customer = new Customer();
                    customer.CustomerId = reader.GetString(0);
                    customer.Name = reader.GetString(1);
                    customer.Password = reader.GetString(2);
                    customer.Email = reader.GetString(3);
                    customer.Gender = reader.GetString(4);
                    customer.Security = reader.GetString(5);
                    customer.Status = reader.GetString(6);
                    customer.Address = reader.GetString(7);
                    customer.Number = reader.GetString(8);

                    customerList.Add(customer);
                }
            }

            cmd.Connection.Close();
            return customerList;
        }

        
        public List<Customer> GetAllCustomer()
        {
            SqlCommand cmd = sda.GetQuery("SELECT * FROM Customer;");
            cmd.CommandType = CommandType.Text;

            List<Customer> customerList = GetData(cmd);
            return customerList;
        }
        public void UpdateByAdmin(Customer c)
        {
            SqlCommand cmd = sda.GetQuery("UPDATE Customer SET status=@Status WHERE customerId=@CustomerId;");
            cmd.Parameters.AddWithValue("@CustomerId", c.CustomerId);
            cmd.Parameters.AddWithValue("@Status", c.Status);

            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
        }

        public void UpdateCustomer(Customer c)
        {
            SqlCommand cmd = sda.GetQuery("UPDATE Customer SET name=@Name, password=@Password, email=@Email, gender=@Gender, security=@Security, status=@Status, address=@Address, number=@Number WHERE customerId=@CustomerId;");
            cmd.Parameters.AddWithValue("@CustomerId",c.CustomerId);
            cmd.Parameters.AddWithValue("@Name", c.Name);
            cmd.Parameters.AddWithValue("@Password", c.Password);
            cmd.Parameters.AddWithValue("@Email", c.Email);
            cmd.Parameters.AddWithValue("@Gender", c.Gender);
            cmd.Parameters.AddWithValue("@Security", c.Security);
            cmd.Parameters.AddWithValue("@Status", c.Status);
            cmd.Parameters.AddWithValue("@Address", c.Address);
            cmd.Parameters.AddWithValue("@Number",c.Number);

            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
        }


        public Customer SearchCustomer(string customerId)
        {
            SqlCommand cmd = sda.GetQuery("SELECT * FROM Customer WHERE CustomerId = @CustomerId;");
            cmd.Parameters.AddWithValue("@CustomerId", customerId);

            List<Customer> customerList = GetData(cmd);

            if (customerList.Count > 0)
            {
                return customerList[0];
            }
            else
            {
                return null;
            }
        }

        public int GetCustomerCount()
        {
            SqlCommand cmd = sda.GetQuery("SELECT COUNT(*) FROM Customer");
            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            int count = (int)cmd.ExecuteScalar();
            cmd.Connection.Close();
            return count;
        }

        

    }
}
