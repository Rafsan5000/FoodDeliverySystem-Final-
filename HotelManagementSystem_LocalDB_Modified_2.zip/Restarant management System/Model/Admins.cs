using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
namespace FoodDeliverySystem.Model
{
    public class Admins
    {
        private readonly SqlDbDataAccess sda=new SqlDbDataAccess();
        public List<Admin> GetData(SqlCommand cmd)
        {
            cmd.Connection.Open();
            try { using(SqlDataReader r=cmd.ExecuteReader()) { var list=new List<Admin>(); while(r.Read()) list.Add(new Admin { AdminId=r["AdminId"].ToString(), Password=r["Password"].ToString(), Name=r["Name"].ToString(), Number=r["Number"].ToString(), Role=r["Role"].ToString(), IsActive=Convert.ToBoolean(r["IsActive"]) }); return list; } }
            finally { cmd.Connection.Close(); }
        }
        public Admin SearchAdmin(string adminId,string password)
        {
            SqlCommand cmd=sda.GetQuery("SELECT AdminId,Password,Name,Number,Role,IsActive FROM Admin WHERE AdminId=@AdminId AND Password=@Password AND IsActive=1");
            cmd.Parameters.Add("@AdminId",SqlDbType.VarChar,50).Value=adminId; cmd.Parameters.Add("@Password",SqlDbType.VarChar,100).Value=password;
            var list=GetData(cmd); return list.Count>0?list[0]:null;
        }
        public List<Admin> GetAllAdmins()
        { return GetData(sda.GetQuery("SELECT AdminId,Password,Name,Number,Role,IsActive FROM Admin ORDER BY Role DESC,Name")); }
        public void AddAdmin(Admin a)
        {
            SqlCommand cmd=sda.GetQuery("INSERT INTO Admin(AdminId,Password,Name,Number,Role,IsActive) VALUES(@Id,@Pw,@Name,@No,@Role,1)");
            cmd.Parameters.Add("@Id",SqlDbType.VarChar,50).Value=a.AdminId; cmd.Parameters.Add("@Pw",SqlDbType.VarChar,100).Value=a.Password; cmd.Parameters.Add("@Name",SqlDbType.VarChar,100).Value=a.Name; cmd.Parameters.Add("@No",SqlDbType.VarChar,20).Value=a.Number; cmd.Parameters.Add("@Role",SqlDbType.VarChar,30).Value=a.Role;
            cmd.Connection.Open(); try{cmd.ExecuteNonQuery();}finally{cmd.Connection.Close();}
        }
        public void SetActive(string id,bool active)
        {
            SqlCommand cmd=sda.GetQuery("UPDATE Admin SET IsActive=@Active WHERE AdminId=@Id"); cmd.Parameters.Add("@Active",SqlDbType.Bit).Value=active; cmd.Parameters.Add("@Id",SqlDbType.VarChar,50).Value=id; cmd.Connection.Open(); try{cmd.ExecuteNonQuery();}finally{cmd.Connection.Close();}
        }
    }
}
