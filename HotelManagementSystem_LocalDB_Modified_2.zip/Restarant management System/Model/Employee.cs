﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDeliverySystem.Model
{
    public class Employee
    {
        private string employeeId;
        private string password;
        private string name;
        private string address;
        private string number;
        private int salary;
        private string security;

        public Employee()
        {

        }


        public Employee(string employeeId, string password, string name, string address, string number, int salary,string security)
        {
            this.EmployeeId = employeeId;
            this.Password = password;
            this.Name = name;
            this.Address = address;
            this.Number = number;
            this.Salary= salary;
            this.Security = security;
        }

        public string EmployeeId { get => employeeId; set => employeeId = value; }
        public string Password { get => password; set => password = value; }
        public string Name { get => name; set => name = value; }
        public string Address { get => address; set => address = value; }
        public string Number { get => number; set => number = value; }
        public int Salary { get => salary; set => salary = value; }
        public string Security { get => security; set => security = value; }
    }
}
