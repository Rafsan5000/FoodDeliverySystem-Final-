using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace FoodDeliverySystem.Model
{
    public class LogIns
    {
        private readonly SqlDbDataAccess sda = new SqlDbDataAccess();

        public void AddLogIn(LogIn logIn)
        {
            const string sql = @"INSERT INTO dbo.LogIn(LogId,Password,Security,Role)
                                 VALUES(@LogId,@Password,@Security,@Role);";

            using (SqlCommand cmd = sda.GetQuery(sql))
            {
                AddParameters(cmd, logIn);
                cmd.Connection.Open();
                try { cmd.ExecuteNonQuery(); }
                finally { cmd.Connection.Close(); }
            }
        }

        public void UpdateLogIn(LogIn logIn)
        {
            const string sql = @"UPDATE dbo.LogIn
                                 SET Password=@Password, Security=@Security, Role=@Role
                                 WHERE LogId=@LogId;";

            using (SqlCommand cmd = sda.GetQuery(sql))
            {
                AddParameters(cmd, logIn);
                cmd.Connection.Open();
                try { cmd.ExecuteNonQuery(); }
                finally { cmd.Connection.Close(); }
            }
        }

        public LogIn SearchLogIn(string logId)
        {
            const string sql = @"SELECT LogId,Password,Security,Role
                                 FROM dbo.LogIn WHERE LogId=@LogId;";

            using (SqlCommand cmd = sda.GetQuery(sql))
            {
                cmd.Parameters.Add("@LogId", SqlDbType.VarChar, 50).Value = logId;
                List<LogIn> list = GetData(cmd);
                return list.Count > 0 ? list[0] : null;
            }
        }

        public LogIn SearchLogIn(string logId, string password)
        {
            const string sql = @"SELECT LogId,Password,Security,Role
                                 FROM dbo.LogIn
                                 WHERE LogId=@LogId AND Password=@Password;";

            using (SqlCommand cmd = sda.GetQuery(sql))
            {
                cmd.Parameters.Add("@LogId", SqlDbType.VarChar, 50).Value = logId;
                cmd.Parameters.Add("@Password", SqlDbType.VarChar, 100).Value = password;
                List<LogIn> list = GetData(cmd);
                return list.Count > 0 ? list[0] : null;
            }
        }

        public List<LogIn> GetData(SqlCommand cmd)
        {
            List<LogIn> list = new List<LogIn>();
            cmd.Connection.Open();
            try
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new LogIn
                        {
                            LogId = reader.GetString(0),
                            Password = reader.GetString(1),
                            Security = reader.GetString(2),
                            Role = reader.GetString(3)
                        });
                    }
                }
            }
            finally
            {
                cmd.Connection.Close();
            }
            return list;
        }

        public void DeleteLogIn(string logId)
        {
            using (SqlCommand cmd = sda.GetQuery("DELETE FROM dbo.LogIn WHERE LogId=@LogId;"))
            {
                cmd.Parameters.Add("@LogId", SqlDbType.VarChar, 50).Value = logId;
                cmd.Connection.Open();
                try { cmd.ExecuteNonQuery(); }
                finally { cmd.Connection.Close(); }
            }
        }

        private static void AddParameters(SqlCommand cmd, LogIn logIn)
        {
            cmd.Parameters.Add("@LogId", SqlDbType.VarChar, 50).Value = logIn.LogId;
            cmd.Parameters.Add("@Password", SqlDbType.VarChar, 100).Value = logIn.Password;
            cmd.Parameters.Add("@Security", SqlDbType.VarChar, 100).Value = logIn.Security;
            cmd.Parameters.Add("@Role", SqlDbType.VarChar, 30).Value = logIn.Role;
        }
    }
}
